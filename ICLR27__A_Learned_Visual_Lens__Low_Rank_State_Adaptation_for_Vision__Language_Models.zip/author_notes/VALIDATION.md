# Final artifact validation

Date: 2026-09-14.

## Performed in this session

- Built the single `main.tex` using pdfLaTeX, the bundled official ICLR2027 style, and BibTeX.
- Rebuilt after regenerating the four numerical charts.
- Checked `maintextend` in the LaTeX auxiliary output: **page9**.
- Checked the full PDF: **14pages**, all US Letter (612×792points). Pages1–9 are main text; pages10–11 contain the statements and references; pages12–14 contain appendices.
- Found no unresolved references/citations, no overfull boxes, and no LaTeX warnings in the final build log.
- Rendered and visually inspected every page. Tables, mathematical notation, captions, and numerical figure labels have no observed clipping or collisions.
- Compared four bundled official dependency files byte-for-byte with the downloaded ICLR2027 template: `.sty`, `.bst`, `natbib.sty`, `fancyhdr.sty` are unchanged.
- Confirmed exactly one `.tex` manuscript and no sample paper, old alternate-title entry point, or embedded font files.
- Checked arithmetic in Figure1 and the mean/sample-SD of the prior-mixture diagnostic.
- Verified the local controller chain rule by double-precision finite differences; checked zero-mask isolation, the residual norm bound, and the retained orthogonal component. This is a numerical mathematical check, not a real-VLM gradient-path check.
- Created the ZIP, tested its CRC, extracted it into a fresh directory, and successfully compiled the extracted project. The fresh build again had9 main-text pages and14 total pages.
- Python plotting/audit scripts pass compilation and their supplied arithmetic checks.

## Not performed

No GPU model fitting, benchmark evaluation, new statistical reanalysis from raw prediction records, independent external reviewer/model review, human coauthor approval, or GitHub push was performed in this writing session. The manuscript's experimental results remain the attributed archived observations.

The draft is complete as a writing artifact. `EXPERIMENTS_TO_COMPLETE.md` records the experimental checks still needed before stronger claims or submission certification.
