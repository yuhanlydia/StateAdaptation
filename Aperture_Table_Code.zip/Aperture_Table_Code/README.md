# Aperture: code for the empty cross-backbone table

New additive implementation of the approved64-state table (including native
Qwen3 and Gemma3 adapters). It is not already present in inspected remote main.
No GPU benchmark result or successful GitHub push is asserted.

On a machine with GitHub write access:

```bash
bash apply_and_push.sh /path/to/StateAdaptation --push
```

Then read `APERTURE_TABLE_HANDOFF.md` in the repo. Do not run the135/180-state
medical matrices to fill this table. Verification limitations are explicit in
VERIFICATION.json. The payload contains only source/config/tests/docs, no
medical images, local predictions, weights or authentication data.
