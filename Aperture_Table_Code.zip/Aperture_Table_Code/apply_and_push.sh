#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:?Usage: bash apply_and_push.sh /path/to/StateAdaptation [--push]}"
PUSH="${2:-}"
[[ -z "$PUSH" || "$PUSH" == "--push" ]] || { echo 'Unknown option'; exit 2; }
cd "$REPO"
[[ "$(git branch --show-current)" == main ]] || { echo 'Switch to main first; no automatic branch or dirty-worktree changes.'; exit 2; }
[[ -z "$(git status --porcelain)" ]] || { echo 'Working tree is not clean. Preserve your changes before applying.'; exit 2; }
URL="$(git remote get-url origin)"
case "$URL" in
 https://github.com/yuhanlydia/StateAdaptation|https://github.com/yuhanlydia/StateAdaptation.git|git@github.com:yuhanlydia/StateAdaptation.git) ;;
 *) echo 'Unexpected target repository; stopped.'; exit 2;;
esac
BASE=92a6b54ec4b393276c5df97f729e06decfe578dc
git merge-base --is-ancestor "$BASE" HEAD || { echo 'Pull the inspected main ancestry first. No force operation will be used.'; exit 2; }
python3 - "$HERE" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);manifest=json.loads((root/'FILES.json').read_text())
for name,h in manifest.items():
 p=root/'payload'/name
 if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise SystemExit(f'Payload hash mismatch: {name}')
PY
git apply --check "$HERE/aperture_table.patch"
git apply "$HERE/aperture_table.patch"
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python3 -m pytest -q -o addopts= tests_aperture_table
python3 -m compileall -q src/aperture_table tests_aperture_table scripts/run_aperture_table.py
bash -n scripts/run_aperture_table.sh
mapfile -t FILES < <(python3 -c 'import json,sys;print("\n".join(json.load(open(sys.argv[1]))))' "$HERE/FILES.json")
git add -- "${FILES[@]}"
git commit -m "Add fixed64-state Qwen2.5/Qwen3/Gemma visual-lens table protocol and verified exports"
if [[ "$PUSH" == "--push" ]]; then
 git push origin HEAD:main
 git ls-remote origin refs/heads/main
else
 echo 'Committed locally; --push was not requested.'
fi
